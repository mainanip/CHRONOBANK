-- PostgreSQL Schema for ChronoBank System

-- Drop existing tables (optional, for clean setup)
DROP TABLE IF EXISTS investments CASCADE;
DROP TABLE IF EXISTS transaction_log CASCADE;
DROP TABLE IF EXISTS transactions CASCADE;
DROP TABLE IF EXISTS accounts CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Users Table
CREATE TABLE users (
    user_id VARCHAR(255) PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    reputation_score INT DEFAULT 0,
    risk_score INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Accounts Table
CREATE TABLE accounts (
    account_id VARCHAR(255) PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    account_type VARCHAR(50) NOT NULL, -- e.g., 'BASIC', 'INVESTOR', 'LOAN'
    balance DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    status VARCHAR(50) NOT NULL, -- e.g., 'ACTIVE', 'OVERDRAWN', 'FROZEN'
    preferences_json JSONB, -- For AccountPreferences (transactionLimitPerDay, notificationPreferences, etc.)
    creation_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    -- Fields specific to LoanAccount
    loan_amount DECIMAL(15,2) NULL,
    loan_interest_rate DECIMAL(5,4) NULL, -- e.g., 0.05 for 5%
    loan_due_date TIMESTAMP WITH TIME ZONE NULL,
    loan_repayment_strategy VARCHAR(100) NULL, -- Name of the strategy class or identifier
    -- Fields specific to InvestorAccount
    investor_interest_rate DECIMAL(5,4) NULL -- e.g., 0.03 for 3%
);

-- Transactions Table
CREATE TABLE transactions (
    transaction_id VARCHAR(255) PRIMARY KEY,
    transaction_type VARCHAR(50) NOT NULL, -- e.g., 'TRANSFER', 'LOAN_DISBURSEMENT', 'LOAN_REPAYMENT', 'INVESTMENT_NEW', 'INVESTMENT_DIVEST', 'INTEREST_ACCRUAL', 'FEE_CHARGE'
    from_account_id VARCHAR(255) REFERENCES accounts(account_id) ON DELETE SET NULL NULL, -- SET NULL if account is deleted, or handle appropriately
    to_account_id VARCHAR(255) REFERENCES accounts(account_id) ON DELETE SET NULL NULL,
    amount DECIMAL(15, 2) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) NOT NULL, -- e.g., 'PENDING', 'COMPLETED', 'FAILED', 'REVERTED'
    description TEXT NULL, -- e.g., reason for failure, details of transaction
    related_investment_id VARCHAR(255) NULL -- Link to an investment if applicable
);

-- Transaction Log Table (for ChronoLedger, can be more detailed for audit)
-- This can be a more detailed audit trail if needed, or ChronoLedger can directly query 'transactions' table.
-- For simplicity, we'll assume ChronoLedger primarily uses the 'transactions' table.
-- If a separate, immutable log is strictly required by Singleton pattern's intent:
CREATE TABLE transaction_log (
    log_id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(255) NOT NULL REFERENCES transactions(transaction_id) ON DELETE CASCADE,
    logged_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    event_description TEXT NOT NULL, -- e.g., 'Transaction initiated', 'Transaction completed', 'Attempted undo'
    snapshot_details JSONB NULL -- Optional: JSON snapshot of relevant data at the time of logging
);

-- Investments Table (For InvestorAccount)
CREATE TABLE investments (
    investment_id VARCHAR(255) PRIMARY KEY,
    account_id VARCHAR(255) NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
    investment_type VARCHAR(100) NOT NULL, -- e.g., 'TIME_BONDS', 'FUTURE_PROJECT_X'
    amount_invested DECIMAL(15,2) NOT NULL,
    start_date TIMESTAMP WITH TIME ZONE NOT NULL,
    maturity_date TIMESTAMP WITH TIME ZONE NULL, -- For investments with a defined end
    current_value DECIMAL(15,2) NOT NULL,
    status VARCHAR(50) NOT NULL, -- e.g., 'ACTIVE', 'MATURED', 'SOLD', 'CANCELLED'
    last_updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_accounts_user_id ON accounts(user_id);
CREATE INDEX idx_transactions_from_account_id ON transactions(from_account_id);
CREATE INDEX idx_transactions_to_account_id ON transactions(to_account_id);
CREATE INDEX idx_transactions_timestamp ON transactions(timestamp);
CREATE INDEX idx_investments_account_id ON investments(account_id);

-- Comments explaining table choices and relationships:
COMMENT ON TABLE users IS 'Stores information about ChronoBank users.';
COMMENT ON COLUMN users.reputation_score IS 'Score reflecting user transaction history and reliability.';
COMMENT ON COLUMN users.risk_score IS 'Score assessing potential risk associated with the user.';

COMMENT ON TABLE accounts IS 'Stores information about different types of time accounts.';
COMMENT ON COLUMN accounts.account_type IS 'Type of account: BASIC, INVESTOR, LOAN.';
COMMENT ON COLUMN accounts.status IS 'Current status of the account: ACTIVE, OVERDRAWN, FROZEN.';
COMMENT ON COLUMN accounts.preferences_json IS 'Stores account-specific preferences like transaction limits and notification settings as JSON.';
COMMENT ON COLUMN accounts.loan_repayment_strategy IS 'Identifier for the loan repayment strategy being used.';

COMMENT ON TABLE transactions IS 'Records all financial transactions within the ChronoBank system.';
COMMENT ON COLUMN transactions.transaction_type IS 'Category of the transaction, e.g., TRANSFER, LOAN_DISBURSEMENT.';
COMMENT ON COLUMN transactions.status IS 'Current state of the transaction: PENDING, COMPLETED, FAILED, REVERTED.';
COMMENT ON COLUMN transactions.related_investment_id IS 'Foreign key to investments table if transaction is related to an investment.';

COMMENT ON TABLE transaction_log IS 'Provides an audit trail for transactions, complementing the main transactions table for the ChronoLedger.';
COMMENT ON COLUMN transaction_log.event_description IS 'Describes the event that was logged, e.g., transaction initiation, completion, or an error.';

COMMENT ON TABLE investments IS 'Stores details about investments made by users with InvestorAccounts.';
COMMENT ON COLUMN investments.status IS 'Current status of the investment: ACTIVE, MATURED, SOLD.';

-- Note: For a production system, consider adding more constraints, audit triggers, and potentially partitioning for very large tables like transactions.
-- The `hashed_password` column implies that password hashing will be handled at the application layer before storing.
-- `preferences_json` in `accounts` table is a flexible way to store various account settings without altering schema frequently.

